<?php

$config = [
    "host"          =>          "smtp-auth.mailprotect.be", // contoh smtp-relay.gmail.com
    "port"          =>          587, //contoh 465, 587
    "username"      =>          "drietandmagazine@absvzw.be", // contoh admin@kontol.com
    "password"      =>          "boebke", // password smtp lu
    "from-mail"     =>          "info@deleye.com", // from mail
    "from-name"     =>          "Service", // from name
    "subject"       =>          "Happy", // subject mail
    "letter"        =>          "coli.txt", // leter name
    "list"          =>          "list.txt" // list name
];

?>