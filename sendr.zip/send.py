import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header
from email.utils import formataddr, formatdate, make_msgid
import random
import time
import os
from colorama import init, Fore
import socket

# Initialize Colorama
init()

# Banner for Deexter07
banner = f"""{Fore.YELLOW}
███╗   ███╗███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗ 
████╗ ████║██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗
██╔████╔██║█████╗  █████╗  ██████╔╝██║   ██║█████╗  ██████╔╝
██║╚██╔╝██║██╔══╝  ██╔══╝  ██╔══██╗██║   ██║██╔══╝  ██╔══██╗
██║ ╚═╝ ██║███████╗███████╗██║  ██║╚██████╔╝███████╗██║  ██║
╚═╝     ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝
{Fore.RESET}
"""

# Generate a random color
def random_color():
    colors = [Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN]
    return random.choice(colors)

# Print banner with random color
print(random_color() + banner + Fore.BLUE + "[@Deexter07]" + Fore.RESET)

# Function to read lines from a file and return them as a list
def load_list_from_file(file_path):
    if not os.path.exists(file_path):
        print(f"{Fore.RED}[@Deexter07] File {file_path} does not exist.{Fore.RESET}")
        return []
    with open(file_path, 'r') as file:
        return [line.strip() for line in file if line.strip()]

# Function to read the entire content of a file
def load_file_content(file_path):
    if not os.path.exists(file_path):
        print(f"{Fore.RED}[@Deexter07] File {file_path} does not exist.{Fore.RESET}")
        return ""
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

# Function to send an email via SMTP without proxy
def send_email(smtp_server, to_email, subject, message, sender_name, user_agent):
    smtp_info = smtp_server.split('|')
    if len(smtp_info) < 5:
        print(f"{Fore.RED}[@Deexter07] Invalid SMTP server format: {smtp_server}{Fore.RESET}")
        return False
    host, port, username, password, email_from = smtp_info[:5]
    encryption = smtp_info[5] if len(smtp_info) > 5 else 'tls'
    try:
        # Set up the server with SSL or TLS encryption
        if encryption.lower() == 'ssl':
            server = smtplib.SMTP_SSL(host, int(port))
        elif encryption.lower() == 'tls':
            server = smtplib.SMTP(host, int(port))
            server.starttls()
        else:
            print(f"{Fore.RED}[@Deexter07] Invalid encryption method specified for {host}:{port}{Fore.RESET}")
            return False
        
        # Login to SMTP server
        server.login(username, password)
        
        # Create the email
        msg = MIMEMultipart()
        msg['From'] = formataddr((str(Header(sender_name, 'utf-8')), email_from))
        msg['To'] = to_email
        msg['Subject'] = Header(subject, 'utf-8')
        msg['Reply-To'] = email_from
        msg['Return-Path'] = email_from
        msg['Date'] = formatdate(localtime=True)
        msg['Message-ID'] = make_msgid()

        # Attach the message content
        body = MIMEText(message, 'html', 'utf-8')
        msg.attach(body)

        # Add headers to improve email deliverability and include the user agent
        msg['MIME-Version'] = '1.0'
        #msg['User-Agent'] = user_agent
        msg['X-Priority'] = '3'  # Normal priority
        msg['X-MSMail-Priority'] = 'Normal'
        msg['X-Mailer'] = 'Customer.io (dgTK1QUDAP67ywH9u8sBAZF1iTs77FxZ-47e7_r8Aw==; +https://whatis.customeriomail.com)'
        msg['List-Unsubscribe'] = '<mailto:32.MRTVISZRKFKUIQKQGY3XS52IHF2TQ42CIFNEMMLJKRZTON2GPBNC2NBXMU3V64RYIF3T2PI=@unsubscribe2.customer.io>, <https://e.customeriomail.com/unsubscribe/dgTK1QUDAP67ywH9u8sBAZF1iTs77FxZ-47e7_r8Aw==>'
        msg['X-Sender'] = email_from
        msg['Feedback-ID'] = f'{random.randint(1000,9999)}'

        # Print sender name and SMTP server being used
        print(f"{Fore.CYAN}[@Deexter07] Sending email from {sender_name} using SMTP server {host}:{port} with User-Agent: {user_agent}{Fore.RESET}")

        # Send the email
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print(f"{Fore.RED}[@Deexter07] Failed to send email from {email_from} ({sender_name}) to {to_email}: {str(e)}{Fore.RESET}")
        return False

# Load data from files
smtp_servers = load_list_from_file("smtp.txt")
email_addresses = load_list_from_file("email.txt")
email_subjects = load_list_from_file("subject.txt")
sender_names = load_list_from_file("name.txt")
user_agents = load_list_from_file("useragents.txt")
message = load_file_content("letter.html")

# Shuffle lists for better randomization
random.shuffle(smtp_servers)
random.shuffle(sender_names)

# Sending emails
email_count = 0
failed_emails = []

for to_email in email_addresses:
    smtp_server = random.choice(smtp_servers)
    sender_name = random.choice(sender_names)
    subject = random.choice(email_subjects)
    user_agent = random.choice(user_agents)
    
    # Attempt to send email
    if not send_email(smtp_server, to_email, subject, message, sender_name, user_agent):
        failed_emails.append((smtp_server, to_email, subject, message, sender_name, user_agent))
    else:
        email_count += 1
        print(f"{Fore.GREEN}[@Deexter07] Email {email_count} sent successfully to {to_email}{Fore.RESET}")
    
    delay_time = random.uniform(30, 60)  # Random delay between 2 to 3 seconds
    time.sleep(delay_time)

# Retry sending failed emails
for smtp_server, to_email, subject, message, sender_name, user_agent in failed_emails:
    if send_email(smtp_server, to_email, subject, message, sender_name, user_agent):
        email_count += 1
        print(f"{Fore.GREEN}[@Deexter07] Email {email_count} (retry) sent successfully to {to_email}{Fore.RESET}")
    else:
        print(f"{Fore.RED}[@Deexter07] Failed to retry sending email to {to_email}{Fore.RESET}")

print(f"{Fore.BLUE}[@Deexter07] Finished sending emails. Total sent: {email_count}{Fore.RESET}")
