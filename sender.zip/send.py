import smtplib
import socks
import socket
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header
from email.utils import formataddr, formatdate, make_msgid
import random
import time
import os
from colorama import init, Fore

# Initialize Colorama
init()

# Function to load lines from a file
def load_list_from_file(file_path):
    if not os.path.exists(file_path):
        print(f"{Fore.RED}[ERROR] File {file_path} does not exist.{Fore.RESET}")
        return []
    with open(file_path, 'r') as file:
        return [line.strip() for line in file if line.strip()]

# Function to load the entire content of a file
def load_file_content(file_path):
    if not os.path.exists(file_path):
        print(f"{Fore.RED}[ERROR] File {file_path} does not exist.{Fore.RESET}")
        return ""
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

# Function to set up proxy
def setup_proxy(proxy):
    if proxy.startswith('socks4://'):
        socks.set_default_proxy(socks.SOCKS4, proxy.split('//')[1].split(':')[0], int(proxy.split(':')[2]))
    elif proxy.startswith('socks5://'):
        socks.set_default_proxy(socks.SOCKS5, proxy.split('//')[1].split(':')[0], int(proxy.split(':')[2]))
    else:
        # HTTP/HTTPS proxies aren't directly supported by smtplib, so they're ignored here
        pass
    socket.socket = socks.socksocket

# Function to send an email via SMTP
def send_email(smtp_server, to_email, subject, message, sender_name, user_agent, proxy):
    smtp_info = smtp_server.split('|')
    if len(smtp_info) < 5:
        print(f"{Fore.RED}[ERROR] Invalid SMTP server format: {smtp_server}{Fore.RESET}")
        return False
    host, port, username, password, email_from = smtp_info[:5]
    encryption = smtp_info[5] if len(smtp_info) > 5 else 'tls'
    
    try:
        # Set up proxy if provided
        if proxy:
            setup_proxy(proxy)
            print(f"{Fore.CYAN}[INFO] Using proxy: {proxy}{Fore.RESET}")
        
        # Set up the SMTP server with SSL or TLS encryption
        if encryption.lower() == 'ssl':
            server = smtplib.SMTP_SSL(host, int(port))
        elif encryption.lower() == 'tls':
            server = smtplib.SMTP(host, int(port))
            server.starttls()
        else:
            print(f"{Fore.RED}[ERROR] Invalid encryption method specified for {host}:{port}{Fore.RESET}")
            return False
        
        # Login to SMTP server
        server.login(username, password)
        
        # Create the email
        msg = MIMEMultipart()
        msg['From'] = formataddr((str(Header(sender_name, 'utf-8')), email_from))
        msg['To'] = to_email
        msg['Subject'] = Header(subject, 'utf-8')
        msg['Date'] = formatdate(localtime=True)
        msg['Message-ID'] = make_msgid()
        msg['Reply-To'] = email_from
        msg['Return-Path'] = email_from

        # Attach the message content
        body = MIMEText(message, 'html', 'utf-8')
        msg.attach(body)

        # Add headers to improve email deliverability
        msg['MIME-Version'] = '1.0'
        ##msg['User-Agent'] = user_agent
        msg['X-Priority'] = '3'  # Normal priority
        msg['X-MSMail-Priority'] = 'Normal'
        msg['X-Originating-IP'] = f'[{socket.gethostbyname(socket.gethostname())}]'
        msg['List-Unsubscribe'] = '<mailto:unsubscribe-AQjkPkSSBQG4zaIzc4dL1tnMR6CmSdTb6zguc6NltOze0WF2wwnEzehqeyADMcapuyYUrszeHskJB2zczfaf@imh.rsys117.origin.responsys.ocs.oraclecloud.com?subject=List-Unsubscribe>, <https://news.skrill.com/pub/optout/UnsubscribeOneStepConfirmAction?YES=true&_ri_=X0Gzc2X%3DAQjkPkSSBQG4zaIzc4dL1tnMR6CmSdTb6zguc6NltOze0WF2wwnEzehqeyADMcapuyYUrszeHskJB2zczfaf&_ei_=EUlaGGF4SNMvxFF7KucKuWO25azMZvBKX-pNP_RNLHYN4-Z92Gir77TjSqmjaejd4DWMuvjr2wJOjg.>'

        # DKIM, SPF, and DMARC headers can only be properly added by the mail server, so these are left out

        # Print sender name, SMTP server, and proxy being used
        print(f"{Fore.CYAN}[INFO] Sending email from {sender_name} using SMTP server {host}:{port} with User-Agent: {user_agent} via proxy {proxy}{Fore.RESET}")

        # Send the email
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print(f"{Fore.RED}[ERROR] Failed to send email from {email_from} ({sender_name}) to {to_email}: {str(e)}{Fore.RESET}")
        return False

# Load data from files
smtp_servers = load_list_from_file("smtp.txt")
email_addresses = load_list_from_file("email.txt")
email_subjects = load_list_from_file("subject.txt")
sender_names = load_list_from_file("name.txt")
user_agents = load_list_from_file("useragents.txt")
proxies = load_list_from_file("proxy.txt")
message = load_file_content("letter.html")

# Shuffle lists for better randomization
random.shuffle(smtp_servers)
random.shuffle(sender_names)
random.shuffle(proxies)

# Sending emails
email_count = 0
failed_emails = []

for to_email in email_addresses:
    smtp_server = random.choice(smtp_servers)
    sender_name = random.choice(sender_names)
    subject = random.choice(email_subjects)
    user_agent = random.choice(user_agents)
    proxy = random.choice(proxies)
    
    # Attempt to send email
    if not send_email(smtp_server, to_email, subject, message, sender_name, user_agent, proxy):
        failed_emails.append((smtp_server, to_email, subject, message, sender_name, user_agent, proxy))
    else:
        email_count += 1
        print(f"{Fore.GREEN}[INFO] Email {email_count} sent successfully to {to_email}{Fore.RESET}")
    
    delay_time = random.uniform(0, 0)  # Random delay between 2 to 3 seconds
    time.sleep(delay_time)

# Retry sending failed emails
for smtp_server, to_email, subject, message, sender_name, user_agent, proxy in failed_emails:
    if send_email(smtp_server, to_email, subject, message, sender_name, user_agent, proxy):
        email_count += 1
        print(f"{Fore.GREEN}[INFO] Email {email_count} (retry) sent successfully to {to_email}{Fore.RESET}")
    else:
        print(f"{Fore.RED}[ERROR] Failed to retry sending email to {to_email}{Fore.RESET}")

print(f"{Fore.BLUE}[INFO] Finished sending emails. Total sent: {email_count}{Fore.RESET}")
